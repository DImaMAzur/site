# Портфолио — React + Framer Motion + Tailwind

## Быстрый старт

```bash
npm install
npm run dev
```

Сайт откроется на http://localhost:5173

## Сборка (папка dist с index.html)

```bash
npm run build
npm run preview
```

## Стек
- React 19 + TypeScript
- Vite
- Tailwind CSS v4
- Framer Motion
- Lucide React

Исходники: `src/App.tsx`, `src/index.css`, `index.html`
