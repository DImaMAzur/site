import { useEffect, useRef, useState, type MouseEvent, type ReactNode } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'

const ROLES = ['фулстек-разработчик', 'архитектор SaaS', 'инженер ботов', 'продуктовый дизайнер']
const LOAD_WORDS = ['Дизайн', 'Сборка', 'Запуск', 'Масштаб']

const PROJECTS = [
  {
    title: 'Nexus Analytics',
    kind: 'SaaS-дашборд',
    stack: ['Next.js', 'TypeScript', 'Prisma', 'Tailwind', 'Framer Motion'],
    description: 'Полноценная SaaS-платформа аналитики: дашборды в реальном времени, роли и биллинг.',
    span: 'md:col-span-7',
    visual: 'from-[#1a2430] to-[#0e141b]',
  },
  {
    title: 'FlowBot Pro',
    kind: 'Telegram-бот и админка',
    stack: ['Node.js', 'Telegraf', 'React Admin', 'PostgreSQL'],
    description: 'Мультитенантная платформа Telegram-ботов с визуальным конструктором сценариев и подписками.',
    span: 'md:col-span-5',
    visual: 'from-[#16261f] to-[#0c1411]',
  },
  {
    title: 'AgentWave',
    kind: 'AI-лендинг и бэкенд',
    stack: ['Next.js', 'OpenAI API', 'Supabase', 'Tailwind'],
    description: 'Маркетплейс AI-агентов с конструктором промптов и оплатой по использованию.',
    span: 'md:col-span-5',
    visual: 'from-[#1c2030] to-[#10131c]',
  },
  {
    title: 'Lumina UI Kit',
    kind: 'Дизайн-система и SaaS',
    stack: ['React', 'Storybook', 'Tailwind', 'Framer Motion'],
    description: 'Дизайн-система и библиотека компонентов, которую используют три коммерческих SaaS.',
    span: 'md:col-span-7',
    visual: 'from-[#241c18] to-[#14100e]',
  },
]

const SERVICES = [
  ['01', 'Разработка SaaS под ключ', 'Интерфейсы, API, биллинг и модель данных за ними.'],
  ['02', 'Архитектура ботов Telegram и Discord', 'Мультитенантные боты, админки, очереди и подписки.'],
  ['03', 'UI/UX и дизайн-системы', 'Продуманные интерфейсы, которые сразу уходят в компоненты.'],
  ['04', 'Интеграция AI и агенты', 'Сценарии промптов, учёт использования и ассистенты внутри продукта.'],
  ['05', 'Поддержка и масштабирование', 'Остаюсь после запуска: стабильность, итерации и рост.'],
]

function Magnetic({ children, className }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const reduce = useReducedMotion()

  function onMove(e: MouseEvent) {
    if (reduce || !ref.current) return
    const r = ref.current.getBoundingClientRect()
    const x = e.clientX - (r.left + r.width / 2)
    const y = e.clientY - (r.top + r.height / 2)
    ref.current.style.transform = `translate(${x * 0.18}px, ${y * 0.22}px)`
  }
  function reset() {
    if (ref.current) ref.current.style.transform = 'translate(0,0)'
  }

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={reset}
      className={className}
      style={{ transition: 'transform 180ms ease-out' }}
    >
      {children}
    </div>
  )
}

function Loader({ onDone }: { onDone: () => void }) {
  const [n, setN] = useState(0)
  const [word, setWord] = useState(0)
  const reduce = useReducedMotion()

  useEffect(() => {
    if (reduce) {
      onDone()
      return
    }
    const start = performance.now()
    const duration = 2700
    let raf = 0
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration)
      setN(Math.round(p * 100))
      if (p < 1) raf = requestAnimationFrame(tick)
      else window.setTimeout(onDone, 280)
    }
    raf = requestAnimationFrame(tick)
    const words = window.setInterval(() => setWord((w) => (w + 1) % LOAD_WORDS.length), 650)
    return () => {
      cancelAnimationFrame(raf)
      clearInterval(words)
    }
  }, [onDone, reduce])

  return (
    <motion.div
      className="fixed inset-0 z-50 bg-bg text-fg"
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="absolute top-8 left-8 text-xs tracking-[0.3em] text-muted uppercase">Портфолио</div>
      <div className="absolute inset-0 grid place-items-center">
        <AnimatePresence mode="wait">
          <motion.span
            key={word}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            className="font-display italic text-5xl md:text-7xl text-fg/80"
          >
            {LOAD_WORDS[word]}
          </motion.span>
        </AnimatePresence>
      </div>
      <div className="absolute bottom-10 right-8 font-display text-6xl md:text-8xl tabular-nums">
        {String(n).padStart(3, '0')}
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-line">
        <div className="accent-fill h-full origin-left" style={{ transform: `scaleX(${n / 100})` }} />
      </div>
    </motion.div>
  )
}

export default function App() {
  const [loading, setLoading] = useState(true)
  const [role, setRole] = useState(0)
  const reduce = useReducedMotion()

  useEffect(() => {
    if (reduce) return
    const id = window.setInterval(() => setRole((r) => (r + 1) % ROLES.length), 2500)
    return () => clearInterval(id)
  }, [reduce])

  return (
    <div className="bg-bg text-fg min-h-screen">
      <AnimatePresence>{loading && <Loader onDone={() => setLoading(false)} />}</AnimatePresence>

      <header className="fixed top-0 inset-x-0 z-40 flex justify-center pt-4 px-4">
        <nav className="glass noise rounded-full flex flex-wrap justify-center items-center gap-1 px-2 py-2 text-xs sm:text-sm max-w-full">
          <a href="#top" className="px-3 py-2 font-display italic">
            AN
          </a>
          {(
            [
              ['Работы', '#work'],
              ['Услуги', '#services'],
              ['Обо мне', '#about'],
              ['Контакты', '#contact'],
            ] as const
          ).map(([label, href]) => (
            <a key={label} href={href} className="px-3 py-2 text-muted hover:text-fg rounded-full">
              {label}
            </a>
          ))}
        </nav>
      </header>

      <section
        id="top"
        className="relative min-h-screen flex flex-col justify-end overflow-hidden px-6 pb-16 pt-28 md:px-16"
      >
        <div className="orb orb-a accent-fill w-72 h-72 -top-10 -left-10" />
        <div className="orb orb-b bg-fg/20 w-80 h-80 bottom-10 right-0" />
        <p className="text-xs tracking-[0.28em] text-muted uppercase mb-6">Фулстек × Дизайн × AI</p>
        <h1 className="font-display italic leading-[0.9] tracking-tight text-6xl sm:text-8xl lg:text-9xl">
          Алекс Новак
        </h1>
        <p className="mt-6 text-lg md:text-2xl text-muted min-h-8">
          <span key={role} className="font-display italic text-fg">
            {ROLES[role]}
          </span>
        </p>
        <p className="mt-4 max-w-xl text-muted leading-relaxed">
          Проектирую и собираю готовые к продакшену SaaS-продукты и умных ботов. От точных интерфейсов до
          масштабируемых бэкендов и AI-автоматизаций.
        </p>
        <div className="mt-10 flex flex-wrap gap-3">
          <Magnetic>
            <a
              href="#work"
              className="inline-flex items-center gap-2 rounded-full bg-fg text-bg px-7 py-3.5 text-sm font-medium"
            >
              Смотреть проекты
            </a>
          </Magnetic>
          <Magnetic>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-full border border-line px-7 py-3.5 text-sm hover:border-transparent"
              style={{
                backgroundImage:
                  'linear-gradient(#0a0a0a,#0a0a0a), linear-gradient(90deg,#89AACC,#4E85BF)',
                backgroundOrigin: 'border-box',
                backgroundClip: 'padding-box, border-box',
              }}
            >
              Написать <ArrowUpRight size={16} />
            </a>
          </Magnetic>
        </div>
      </section>

      <section id="work" className="px-6 md:px-16 py-20 max-w-6xl mx-auto">
        <p className="text-xs tracking-[0.28em] text-muted uppercase">Избранные работы</p>
        <h2 className="font-display italic text-5xl md:text-7xl mt-3">Проекты</h2>
        <div className="mt-10 grid grid-cols-1 md:grid-cols-12 gap-5">
          {PROJECTS.map((p, i) => (
            <motion.article
              key={p.title}
              initial={reduce ? false : { opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ delay: i * 0.06, duration: 0.5 }}
              className={`group relative overflow-hidden rounded-3xl border border-line bg-surface min-h-72 ${p.span}`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${p.visual}`} />
              <div className="absolute inset-4 rounded-2xl border border-white/10 opacity-60" />
              <div className="absolute right-6 top-6 text-xs tracking-widest text-muted uppercase">{p.kind}</div>
              <div className="absolute inset-0 bg-bg/70 opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-md" />
              <div className="relative z-10 h-full flex flex-col justify-end p-6 md:p-8">
                <h3 className="font-display italic text-3xl md:text-4xl">{p.title}</h3>
                <p className="mt-2 text-sm text-muted max-w-md leading-relaxed">{p.description}</p>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {p.stack.map((s) => (
                    <li key={s} className="text-xs text-fg/80 border border-white/15 rounded-full px-3 py-1">
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section id="services" className="px-6 md:px-16 py-16 max-w-6xl mx-auto">
        <h2 className="font-display italic text-5xl md:text-7xl mb-8">Услуги</h2>
        <ol className="divide-y divide-line border-y border-line">
          {SERVICES.map(([n, title, body]) => (
            <li key={n} className="grid md:grid-cols-[6rem_1fr_1.2fr] gap-3 py-8 items-baseline">
              <span className="font-display italic text-3xl text-muted">{n}</span>
              <h3 className="text-xl md:text-2xl">{title}</h3>
              <p className="text-muted leading-relaxed">{body}</p>
            </li>
          ))}
        </ol>
      </section>

      <section id="about" className="px-6 md:px-16 py-16 max-w-6xl mx-auto">
        <h2 className="font-display italic text-5xl md:text-7xl">Обо мне</h2>
        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted">
          Продукт, дизайн и разработка для меня одно ремесло. Работа — это система за экраном: как
          движется пользователь, кому принадлежат данные и как продукт живёт после запуска. Остаюсь на
          поддержке, когда это нужно.
        </p>
        <dl className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6">
          {(
            [
              ['40+', 'Проекты'],
              ['12', 'Запущено SaaS'],
              ['3+', 'Года'],
              ['Открыт', 'Фуллтайм'],
            ] as const
          ).map(([k, v]) => (
            <div key={v} className="border-t border-line pt-4">
              <dt className="font-display italic text-4xl md:text-5xl">{k}</dt>
              <dd className="mt-2 text-sm text-muted uppercase tracking-widest">{v}</dd>
            </div>
          ))}
        </dl>
      </section>

      <footer id="contact" className="px-6 md:px-16 pt-16 pb-10">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-display italic text-5xl md:text-7xl leading-[0.95]">
            Готовы собрать
            <br />
            ваш SaaS?
          </h2>
          <Magnetic className="inline-block mt-8">
            <a
              href="mailto:hello@alexnovak.dev"
              className="inline-flex items-center gap-2 rounded-full bg-fg text-bg px-7 py-3.5 text-sm font-medium"
            >
              hello@alexnovak.dev <ArrowUpRight size={16} />
            </a>
          </Magnetic>
          <div className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-line pt-6 text-sm text-muted">
            <div className="flex items-center gap-2">
              <span className="pulse-dot inline-block w-2 h-2 rounded-full bg-accent-a" />
              Открыт к фуллтайм
            </div>
            <div className="flex gap-5">
              <a className="hover:text-fg" href="https://github.com" target="_blank" rel="noreferrer">
                GitHub
              </a>
              <a className="hover:text-fg" href="https://t.me" target="_blank" rel="noreferrer">
                Telegram
              </a>
              <a className="hover:text-fg" href="https://linkedin.com" target="_blank" rel="noreferrer">
                LinkedIn
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
